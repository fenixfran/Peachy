//
//  ViewControllerRegistroSQL.m
//  Peachy
//
//  Created by Francisco Javier Guadarrama Abarca on 5/25/14.
//  Copyright (c) 2014 Francisco Javier Guadarrama Abarca. All rights reserved.
//

#import "ViewControllerRegistroSQL.h"
#import <sqlite3.h>
#import "AppDelegate.h"

@interface ViewControllerRegistroSQL ()


@end

@implementation ViewControllerRegistroSQL

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad

{
    
    [super viewDidLoad];
    _TextFieldNombre.delegate = self;
    _TextFieldApM.delegate = self;
    _TextFieldApP.delegate = self;
    _TextFieldCorreo.delegate = self;
    _TextFieldCuenta.delegate = self;
    _TextFieldPass.delegate = self;

    // Do any additional setup after loading the view.
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)ClickBotonBienvenido:(id)sender {
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    
    
    sqlite3 *dataBase;
    sqlite3_stmt *sentencia;
    
    if (sqlite3_open([appDelegate.dataBasePath UTF8String], &dataBase)== SQLITE_OK){
    NSString *sql = [NSString stringWithFormat:@"insert into Peachy (\"Nombre\", \"Apellido Paterno\", \"Apellido Materno\", \"Cuenta de cobro\") VALUES (\"%@\", \"%@\", \"%@\", \"%i\")", self.TextFieldNombre.text , self.TextFieldApP.text, self.TextFieldApM.text, [self.TextFieldCuenta.text intValue]];
        
        NSLog(@"%@", sql);
        
        if (sqlite3_prepare_v2(dataBase, [sql UTF8String],  -1, &sentencia, NULL)== SQLITE_OK){
            while  (sqlite3_step(sentencia)== SQLITE_OK){
            }
            
        } 
        sqlite3_finalize(sentencia);
    }else{
        NSLog(@"No se a podido acceder a la DB");
    }
    sqlite3_close(dataBase);
    }
@end
