//
//  ViewControllerRegistroSQL.h
//  Peachy
//
//  Created by Francisco Javier Guadarrama Abarca on 5/25/14.
//  Copyright (c) 2014 Francisco Javier Guadarrama Abarca. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerRegistroSQL : UIViewController <UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet UITextField *TextFieldNombre;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldApP;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldApM;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldCuenta;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldCorreo;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldPass;


- (IBAction)ClickBotonBienvenido:(id)sender;

@end
