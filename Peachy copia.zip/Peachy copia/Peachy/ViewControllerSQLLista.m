//
//  ViewControllerSQLLista.m
//  Peachy
//
//  Created by Francisco Javier Guadarrama Abarca on 5/25/14.
//  Copyright (c) 2014 Francisco Javier Guadarrama Abarca. All rights reserved.
//

#import "ViewControllerSQLLista.h"
#import "AppDelegate.h"
#import <sqlite3.h>

@interface ViewControllerSQLLista (){
    NSMutableArray *usuarios;
    
}

@end

@implementation ViewControllerSQLLista

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;}

- (void)viewDidLoad
{
    [super viewDidLoad];
    usuarios = [[NSMutableArray alloc] init];
    [self cargarUsuarios];
    [self.tableView reloadData];
     
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [usuarios count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPAth:(NSIndexPath *)indexPath
{
    static NSString *CellIndentifier = @"Cell";
    
    NSDictionary *dic = [usuarios objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIndentifier];
    }
    
    cell.textLabel.text = [dic objectForKey:@"Nombre"];
    
    return cell;
    
}

-(void) cargarUsuarios{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    sqlite3 *database;
    sqlite3_stmt *sentencia;
    
    if (sqlite3_open([appDelegate.dataBasePath UTF8String], &database)== SQLITE_OK) {
        NSString *sentenciaSQL = [NSString stringWithFormat:@"select * from usuarios"];
        if (sqlite3_prepare_v2(database, [sentenciaSQL UTF8String], -1,  &sentencia, NULL) == SQLITE_OK) {
            while (sqlite3_step(sentencia) == SQLITE_ROW) {
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                NSString *nombre = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sentencia, 0)];
                [dic setValue:nombre forKey:@"nombre"];
                [usuarios addObject:dic];
                
            }
        }
        sqlite3_finalize(sentencia);
    }
    sqlite3_close(database);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
