//
//  ViewControllerWebView.h
//  Peachy
//
//  Created by Francisco Javier Guadarrama Abarca on 5/25/14.
//  Copyright (c) 2014 Francisco Javier Guadarrama Abarca. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerWebView : UIViewController{
    IBOutlet UIWebView *web;
    
}
@property (nonatomic, retain) UIWebView *web;

@end
